import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MiapiRoutingModule } from './miapi-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MiapiRoutingModule
  ]
})
export class MiapiModule { }
