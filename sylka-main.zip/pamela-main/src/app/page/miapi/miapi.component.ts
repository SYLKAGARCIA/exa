import { Component } from '@angular/core';

@Component({
  selector: 'app-miapi',
  standalone: true,
  imports: [],
  templateUrl: './miapi.component.html',
  styleUrl: './miapi.component.css'
})
export class MiapiComponent {

}
